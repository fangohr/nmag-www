        
          _S_P_I_D_E_R_C_O_D_E_

--------------------------------------------

Installation: (english)
	1. Upload the content of this smiley-pack into your smiley-folder:
	   -> http://yourdomain.com/phpbb/images/smilies/
	2. Now go into the phpBB-administration and click in the menu on "Smilies"!
	3. Now click on "Import Smiley Pack".
	4. Now choose "sc_smilies.pak"!
	5. I think now you don't need help anymore... :)

Installation: (deutsch)
	1. Uploade den Inhalt des Smiley-packs in dein Smiley-Ordner:
	   -> http://yourdomain.com/phpbb/images/smilies/
	2. Nun gehe in die phpBB-Administration und klick im Menu auf "Smilies"!
	3. Nun Klick auf "Import Smiley Pack".
	4. W�hle nun sc_smilies.pak aus!
	5. Ab jetzt denke ich brauchste keine Hilfe mehr... :)


Updates:
	You find the hole list under ...
	Du findest die ganze Liste auf ... 
	-> http://web.spidercode.de/smilies/

---------------------------------------------

Author:		Spider <admin@spidercode.de>
Website: 	http://www.spidercode.de